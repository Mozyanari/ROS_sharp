# [UrdfImporter](https://github.com/siemens/ros-sharp/tree/master/UrdfImporter) #
[URDF](http://wiki.ros.org/urdf) file parser for [.NET](https://www.microsoft.com/net) applications

__Please see the [Wiki](https://github.com/siemens/ros-sharp/wiki) for further info.__

---

© Siemens AG, 2017-2018

Author: Dr. Martin Bischoff (martin.bischoff@siemens.com)
